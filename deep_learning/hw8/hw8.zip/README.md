## Usage
```
pip install -r requirements.txt
python train.py
```

## Results
### Task1
```
1-layer GRU, hidden_size=200: test_acc=0.771
2-layer LSTM, hidden_size=200: test_acc=0.688
1-layer LSTM, hidden_size=200: test_acc=0.684
1-layer LSTM, hidden_size=100: test_acc=0.653
``` 
### Task2
```Plots are in acc.jpg and loss.jpg```